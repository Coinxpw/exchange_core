/*
 * Description: 
 *     History: yang@haipo.me, 2017/04/28, create
 */

# ifndef _AW_MESSAGE_H_
# define _AW_MESSAGE_H_

int init_message(void);

# endif

